import customtkinter as ctk
import csv
import os
from datetime import datetime

def launch_hospital_app(name, role):
    app = ctk.CTk()
    app.geometry("900x300")
    app.title("Hospital Management System")
    ctk.CTkLabel(app, text=f"Welcome to your Pulse Point dashboard, {role} {name}!", font=("Arial", 25)).pack(pady=10)

    FILES = {
        "users": "user_data.csv",
        "appointments": "appointments.csv",
        "medical_history": "medical_history.csv",
        "prescriptions": "prescriptions.csv"
    }

    for file in FILES.values():
        if not os.path.exists(file):
            with open(file, "w", newline="") as f:
                writer = csv.writer(f)
                if file == FILES["users"]:
                    writer.writerow(["Name", "Age", "Role", "Password"])
                elif file == FILES["appointments"]:
                    writer.writerow(["Patient", "Doctor", "Date", "Consultation Type"])
                elif file == FILES["medical_history"]:
                    writer.writerow(["Patient", "Chronic Diseases", "Past Treatments", "Allergies"])
                elif file == FILES["prescriptions"]:
                    writer.writerow(["Doctor", "Patient", "Prescriptions", "Notes"])

    def save_data(file, data):
        with open(file, "a", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(data)

    def load_data(file):
        records = []
        with open(file, "r") as f:
            reader = csv.reader(f)
            next(reader)
            for row in reader:
                records.append(row)
        return records

    def open_appointment_window():
        app.withdraw()
        appt_window = ctk.CTk()
        appt_window.geometry("900x500")
        appt_window.title("Book an Appointment")

        def confirm_appointment():
            doctor = doctor_dropdown.get()
            date = date_entry.get()
            consultation_type = consultation_dropdown.get()
            if doctor and date:
                save_data(FILES["appointments"], [name, doctor, date, consultation_type])
                app.deiconify()
                appt_window.after(100, appt_window.destroy)
            else:
                status_label.configure(text="Please fill all fields!", text_color="red")

        def go_back():
            app.deiconify()
            appt_window.after(100, appt_window.destroy)

        main_frame = ctk.CTkFrame(appt_window)
        main_frame.pack(pady=20, padx=20, fill="both", expand=True)

        name_entry = ctk.CTkEntry(main_frame)
        name_entry.insert(0, name)
        name_entry.configure(state="disabled")
        name_entry.pack(pady=5)

        doctor_options = ["Dr. John Smith - Cardiology", "Dr. Ana Lopez - Dermatology", "Dr. Jin Kim - Neurology", "Dr. Lily Chan - General Medicine"]
        doctor_dropdown = ctk.CTkComboBox(main_frame, values=doctor_options, width=250)
        doctor_dropdown.set("Select Doctor")
        doctor_dropdown.pack(pady=5)

        date_entry = ctk.CTkEntry(main_frame, placeholder_text="YYYY-MM-DD")
        date_entry.pack(pady=5)

        consultation_dropdown = ctk.CTkComboBox(main_frame, values=["Online", "Physical"], width=150)
        consultation_dropdown.set("Online")
        consultation_dropdown.pack(pady=5)

        appt_button_frame = ctk.CTkFrame(appt_window)
        appt_button_frame.pack(pady=20, padx=20)

        confirm_btn = ctk.CTkButton(appt_button_frame, text="Confirm Appointment", fg_color="#7AB2D3", command=confirm_appointment)
        confirm_btn.grid(row=0, column=0, padx=5)

        back_btn = ctk.CTkButton(appt_button_frame, text="Back", fg_color="#FF6F61", command=go_back)
        back_btn.grid(row=0, column=1, padx=5)

        status_label = ctk.CTkLabel(main_frame, text="", font=("Arial", 12))
        status_label.pack(pady=5)

        appt_window.mainloop()

    def open_patient_records_window():
        app.withdraw()
        records_window = ctk.CTk()
        records_window.geometry("900x500")
        records_window.title("Patient Records")

        main_frame = ctk.CTkFrame(records_window)
        main_frame.pack(pady=20, padx=20, fill="both", expand=True)

        records = load_data(FILES["appointments"])
        found = False
        for record in records:
            if role == "Patient" and record[0] != name:
                continue
            ctk.CTkLabel(main_frame, text=f"{record[0]} | {record[1]} | {record[2]} | {record[3]}").pack()
            found = True

        if not found:
            ctk.CTkLabel(main_frame, text="No records found.", text_color="gray").pack()

        back_btn = ctk.CTkButton(records_window, text="Close", fg_color="#FF6F61", command=lambda: (app.deiconify(), records_window.after(100, records_window.destroy)))
        back_btn.pack(pady=10)

        records_window.mainloop()

    def open_prescriptions_window():
        app.withdraw()
        presc_window = ctk.CTk()
        presc_window.geometry("900x500")
        presc_window.title("Your Prescriptions")

        main_frame = ctk.CTkFrame(presc_window)
        main_frame.pack(pady=20, padx=20, fill="both", expand=True)

        records = load_data(FILES["prescriptions"])
        found = False
        for record in records:
            if role == "Patient" and record[1] != name:
                continue
            ctk.CTkLabel(main_frame, text=f"Doctor: {record[0]} | Prescription: {record[2]} | Notes: {record[3]}").pack()
            found = True

        if not found:
            ctk.CTkLabel(main_frame, text="No prescriptions found.", text_color="gray").pack()

        back_btn = ctk.CTkButton(presc_window, text="Close", fg_color="#FF6F61", command=lambda: (app.deiconify(), presc_window.after(100, presc_window.destroy)))
        back_btn.pack(pady=10)

        presc_window.mainloop()

    def open_medical_notes_window():
        app.withdraw()
        notes_window = ctk.CTk()
        notes_window.geometry("900x500")
        notes_window.title("Medical Notes & Prescriptions")

        main_frame = ctk.CTkFrame(notes_window)
        main_frame.pack(pady=20, padx=20, fill="both", expand=True)
        
        try:
            appointments = []
            with open("appointments.csv", 'r') as file:
                csv_reader = csv.reader(file)
                next(csv_reader) 
                for row in csv_reader:
                    appointments.append(row)
            
            all_patients = [row[0] for row in appointments]
            unique_patients = list(set(all_patients))
            print(f"All available patients: {unique_patients}")
            
        except Exception as e:
            print(f"Error loading data: {e}")
            unique_patients = []

        ctk.CTkLabel(main_frame, text="Select Patient:").pack(pady=(10, 0), anchor="w")
        patient_dropdown = ctk.CTkComboBox(main_frame, values=unique_patients, width=250)
        patient_dropdown.set("Select Patient" if unique_patients != ["No patients found"] else "No patients found")
        patient_dropdown.pack(pady=(5, 15), anchor="w")

        ctk.CTkLabel(main_frame, text="Prescription:").pack(pady=(10, 0), anchor="w")
        prescription_entry = ctk.CTkEntry(main_frame, width=600, placeholder_text="Enter prescription details")
        prescription_entry.pack(pady=(5, 15), fill="x")

        ctk.CTkLabel(main_frame, text="Additional Notes:").pack(pady=(10, 0), anchor="w")
        notes_entry = ctk.CTkEntry(main_frame, width=600, placeholder_text="Enter additional notes")
        notes_entry.pack(pady=(5, 15), fill="x")

        status_label = ctk.CTkLabel(main_frame, text="", text_color="red")
        status_label.pack(pady=5)

        def save_notes():
            patient = patient_dropdown.get()
            prescription = prescription_entry.get()
            notes = notes_entry.get()
            
            if patient and patient != "Select Patient" and patient != "No patients found" and prescription:
                try:
                    current_date = datetime.now().strftime("%Y-%m-%d")
                    with open("prescriptions.csv", 'a', newline='') as file:
                        writer = csv.writer(file)
                        writer.writerow([name, patient, prescription, notes, current_date])
                    
                    status_label.configure(text="Notes saved successfully!", text_color="green")
                    notes_window.after(1000, lambda: app.deiconify())
                    notes_window.after(1100, notes_window.destroy)
                except Exception as e:
                    status_label.configure(text=f"Error saving data: {e}", text_color="red")
            else:
                status_label.configure(text="Please select a patient and enter a prescription!", text_color="red")

        button_frame = ctk.CTkFrame(notes_window)
        button_frame.pack(pady=10)
        
        confirm_btn = ctk.CTkButton(button_frame, text="Save & Close", fg_color="#7AB2D3", command=save_notes)
        confirm_btn.pack(side="left", padx=5)
        
        cancel_btn = ctk.CTkButton(button_frame, text="Cancel", fg_color="#CB5C5C", command=lambda: [app.deiconify(), notes_window.destroy()])
        cancel_btn.pack(side="left", padx=5)

        def on_closing():
            app.deiconify()
            notes_window.destroy()
        
        notes_window.protocol("WM_DELETE_WINDOW", on_closing)
        
        notes_window.mainloop()

    def open_medical_history_window():
        app.withdraw()
        history_window = ctk.CTk()
        history_window.geometry("900x500")
        history_window.title("Medical History")

        main_frame = ctk.CTkFrame(history_window)
        main_frame.pack(pady=20, padx=20, fill="both", expand=True)

        ctk.CTkLabel(main_frame, text="Chronic Diseases:").pack(anchor="w")
        chronic_entry = ctk.CTkEntry(main_frame, width=600, placeholder_text="e.g., Diabetes, Hypertension")
        chronic_entry.pack(pady=(0, 15))

        ctk.CTkLabel(main_frame, text="Past Treatments:").pack(anchor="w")
        treatments_entry = ctk.CTkEntry(main_frame, width=600, placeholder_text="e.g., Surgery in 2020, etc.")
        treatments_entry.pack(pady=(0, 15))

        ctk.CTkLabel(main_frame, text="Allergies:").pack(anchor="w")
        allergies_entry = ctk.CTkEntry(main_frame, width=600, placeholder_text="e.g., Penicillin, Nuts")
        allergies_entry.pack(pady=(0, 15))

        status_label = ctk.CTkLabel(main_frame, text="", text_color="red")
        status_label.pack(pady=10)

        def save_history():
            chronic = chronic_entry.get()
            treatments = treatments_entry.get()
            allergies = allergies_entry.get()

            if chronic or treatments or allergies:
                try:
                    with open("medical_history.csv", 'a', newline='') as file:
                        writer = csv.writer(file)
                        writer.writerow([name, chronic, treatments, allergies])
                    status_label.configure(text="Medical history saved!", text_color="green")
                    history_window.after(1000, lambda: app.deiconify())
                    history_window.after(1100, history_window.destroy)
                except Exception as e:
                    status_label.configure(text=f"Error saving: {e}", text_color="red")
            else:
                status_label.configure(text="Please fill at least one field.", text_color="red")

        button_frame = ctk.CTkFrame(history_window)
        button_frame.pack(pady=10)

        confirm_btn = ctk.CTkButton(button_frame, text="Save & Close", fg_color="#7AB2D3", command=save_history)
        confirm_btn.pack(side="left", padx=5)

        cancel_btn = ctk.CTkButton(button_frame, text="Cancel", fg_color="#CB5C5C", command=lambda: [app.deiconify(), history_window.destroy()])
        cancel_btn.pack(side="left", padx=5)

        history_window.protocol("WM_DELETE_WINDOW", lambda: [app.deiconify(), history_window.destroy()])
        history_window.mainloop()

    def open_medical_history_viewer():
        app.withdraw()
        view_window = ctk.CTk()
        view_window.geometry("900x500")
        view_window.title("Patient Medical Histories")

        main_frame = ctk.CTkFrame(view_window)
        main_frame.pack(pady=20, padx=20, fill="both", expand=True)

        records = load_data(FILES["medical_history"])
        found = False

        if records:
            for record in records:
                patient, chronic, treatment, allergies = record
                history_text = f"Patient: {patient}\n  Chronic Diseases: {chronic}\n  Past Treatments: {treatment}\n  Allergies: {allergies}\n"
                ctk.CTkLabel(main_frame, text=history_text, anchor="w", justify="left").pack(pady=5, anchor="w")
                found = True

        if not found:
            ctk.CTkLabel(main_frame, text="No medical history records found.", text_color="gray").pack()

        back_btn = ctk.CTkButton(view_window, text="Close", fg_color="#FF6F61", command=lambda: (app.deiconify(), view_window.after(100, view_window.destroy)))
        back_btn.pack(pady=10)

        view_window.mainloop()

    def open_account_maintenance():
        app.withdraw()
        account_window = ctk.CTk()
        account_window.geometry("1000x500")
        account_window.title("User Account Maintenance")

        frame = ctk.CTkFrame(account_window)
        frame.pack(pady=20, padx=20, fill="both", expand=True)

        try:
            with open("user_data.csv", "r") as file:
                reader = csv.DictReader(file)
                for row in reader:
                    info = (f"Name: {row['First Name']} {row['Last Name']} | "
                            f"Role: {row['Role']} | Email: {row['Email']} | "
                            f"Gender: {row['Gender']} | Contact: {row['Contact']} | Address: {row['Address']}")
                    ctk.CTkLabel(frame, text=info, anchor="w", justify="left", wraplength=950).pack(pady=2, anchor="w")
        except Exception as e:
            ctk.CTkLabel(frame, text=f"Error loading data: {e}", text_color="red").pack()

        ctk.CTkButton(account_window, text="Close", command=lambda: [app.deiconify(), account_window.destroy()]).pack(pady=10)

        account_window.mainloop()
    
    def open_patient_info_module():
        app.withdraw()
        info_window = ctk.CTk()
        info_window.geometry("1000x500")
        info_window.title("Patient Information Records")

        frame = ctk.CTkFrame(info_window)
        frame.pack(pady=20, padx=20, fill="both", expand=True)

        try:
            with open("user_data.csv", "r") as file:
                reader = csv.DictReader(file)
                found = False
                for row in reader:
                    if row["Role"].lower() == "patient":
                        info = (f"Name: {row['First Name']} {row['Last Name']} | "
                                f"Birthday: {row['Birthday']} | Gender: {row['Gender']} | "
                                f"Email: {row['Email']} | Contact: {row['Contact']} | "
                                f"Address: {row['Address']} | Registered: {row['Registered On']}")
                        ctk.CTkLabel(frame, text=info, anchor="w", justify="left", wraplength=950).pack(pady=2, anchor="w")
                        found = True
                if not found:
                    ctk.CTkLabel(frame, text="No patient records found.", text_color="gray").pack()
        except Exception as e:
            ctk.CTkLabel(frame, text=f"Error loading data: {e}", text_color="red").pack()

        ctk.CTkButton(info_window, text="Close", command=lambda: [app.deiconify(), info_window.destroy()]).pack(pady=10)

        info_window.mainloop()

    # main menu buttons
    dashboard_button_frame = ctk.CTkFrame(app)
    dashboard_button_frame.pack(pady=20)

    button_style = {"width": 200, "height": 100}

    if role == "Patient":
        ctk.CTkButton(dashboard_button_frame, text="Book Appointment", command=open_appointment_window, **button_style).grid(row=0, column=0, padx=10, pady=10)
        ctk.CTkButton(dashboard_button_frame, text="View My Appointments", command=open_patient_records_window, **button_style).grid(row=0, column=1, padx=10, pady=10)
        ctk.CTkButton(dashboard_button_frame, text="View My Prescriptions", command=open_prescriptions_window, **button_style).grid(row=0, column=2, padx=10, pady=10)
        ctk.CTkButton(dashboard_button_frame, text="Update Medical History", command=open_medical_history_window, **button_style).grid(row=0, column=3, padx=10, pady=10)
    elif role == "Doctor":
        ctk.CTkButton(dashboard_button_frame, text="View Patient Records", command=open_patient_records_window, **button_style).grid(row=0, column=0, padx=10, pady=10)
        ctk.CTkButton(dashboard_button_frame, text="Medical Notes & Prescriptions", command=open_medical_notes_window, **button_style).grid(row=0, column=1, padx=10, pady=10)
        ctk.CTkButton(dashboard_button_frame, text="View Medical History", command=open_medical_history_viewer, **button_style).grid(row=10, column=2, padx=10, pady=10)
    elif role == "Nurse":
        ctk.CTkButton(dashboard_button_frame, text="View Patient Records", command=open_patient_records_window, **button_style).grid(row=0, column=0, padx=10, pady=10)
        ctk.CTkButton(dashboard_button_frame, text="View Medical History", command=open_medical_history_viewer, **button_style).grid(row=0, column=1, padx=10, pady=10)
    elif role == "Admin":
        ctk.CTkButton(dashboard_button_frame, text="View Patient Records", command=open_patient_records_window, **button_style).grid(row=0, column=0, padx=10, pady=10)
        ctk.CTkButton(dashboard_button_frame, text="View My Prescriptions", command=open_prescriptions_window, **button_style).grid(row=0, column=1, padx=10, pady=10)
        ctk.CTkButton(dashboard_button_frame, text="View Medical History", command=open_medical_history_viewer, **button_style).grid(row=0, column=2, padx=10, pady=10)
        ctk.CTkButton(dashboard_button_frame, text="Account Maintenance", command=open_account_maintenance, **button_style).grid(row=1, column=0, padx=10, pady=10)
        ctk.CTkButton(dashboard_button_frame, text="Patient Information", command=open_patient_info_module, **button_style).grid(row=1, column=1, padx=10, pady=10)
    app.mainloop()
