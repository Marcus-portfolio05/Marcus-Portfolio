from PIL import Image
import customtkinter as ctk
from CTkMessagebox import CTkMessagebox
import csv
import hashlib
import os
from datetime import datetime
from record_appoint import launch_hospital_app

# main window display
def open_main_window():
    global main_window
    main_window = ctk.CTk() 
    main_window.geometry("400x200")
    main_window.title("Pulse Point") 

    image = ctk.CTkImage(dark_image=Image.open("pulsepointlogohori.png"), size=(350, 50))
    pulsepoint_logo = ctk.CTkLabel(main_window, text="", image=image)
    pulsepoint_logo.pack()

    register_button = ctk.CTkButton(main_window, text="Register", fg_color="#7AB2D3", width=280, height=30, command=open_register_window)
    register_button.pack(pady=5)
    
    login_button = ctk.CTkButton(main_window, text="Login", fg_color="#7AB2D3", width=280, height=30, command=open_login_window)
    login_button.pack(pady=5)
    
    main_window.mainloop()

# register window function
def open_register_window():
    register_window = ctk.CTkToplevel(main_window)
    register_window.geometry("520x430")
    register_window.title("Registration")
    main_window.withdraw()

    regis_frame = ctk.CTkFrame(register_window)
    regis_frame.pack(pady=20, padx=20, fill="both", expand=True)

    regis_labels = ["First Name", "Last Name", "Birthday (MM/DD/YYYY)", "Email", "Gender", "Contact Number", "Address", "Password"]
    regis_entries = {}

    # user information entry boxes
    for i, label in enumerate(regis_labels):
        ctk.CTkLabel(regis_frame, text=label).grid(row=i, column=0, padx=5, pady=5, sticky='w')

        if label == "Gender":
            gender_combobox = ctk.CTkComboBox(regis_frame, values=["Male", "Female", "Other"], width=250)
            gender_combobox.grid(row=i, column=1, padx=5, pady=5)
            gender_combobox.set("Male")
            regis_entries[label] = gender_combobox
        else:
            entry = ctk.CTkEntry(regis_frame, width=250)
            if label == "Password":
                entry.configure(show="*")
            entry.grid(row=i, column=1, padx=5, pady=5)
            regis_entries[label] = entry

    role_label = ctk.CTkLabel(regis_frame, text="Role")
    role_label.grid(row=len(regis_labels), column=0, padx=5, pady=5, sticky='w')
    role_options = ["Doctor", "Nurse", "Patient"]
    role_combobox = ctk.CTkComboBox(regis_frame, values=role_options, width=250)
    role_combobox.grid(row=len(regis_labels), column=1, padx=5, pady=5)
    role_combobox.set("Patient")

    # toggle to see password
    def password_toggle():
        if not regis_entries["Password"].winfo_exists():
            return  
        if regis_entries["Password"].cget("show") == "*":
            regis_entries["Password"].configure(show="")  
            toggle_btn.configure(text="Hide")
        else:
            regis_entries["Password"].configure(show="*")  
            toggle_btn.configure(text="Show")

    toggle_btn = ctk.CTkButton(regis_frame, text="Show", width=60, fg_color="#7AB2D3", command=password_toggle)
    toggle_btn.grid(row=regis_labels.index("Password"), column=2, padx=5, pady=5)

    # clear form function
    def clear_form():
        for entry in regis_entries.values():
            if isinstance(entry, ctk.CTkComboBox):
                entry.set("Male")
            else:
                entry.delete(0, ctk.END)
        role_combobox.set("Patient")

    # registration success function
    def regis_success():
        nonlocal regis_entries, role_combobox  # Use nonlocal to access these variables inside this nested function

        required_fields = ["First Name", "Last Name", "Birthday (MM/DD/YYYY)", "Email", "Gender", "Contact Number", "Address", "Password"]
        for field in required_fields:
            if not regis_entries[field].get().strip():
                CTkMessagebox(title="Error", message=f"Please fill in all the required fields.")
                return

        # hashlib
        hashed_password = hashlib.sha256(regis_entries["Password"].get().encode()).hexdigest()

        # user data csv file creation
        file_exists = os.path.isfile("user_data.csv")
        with open("user_data.csv", 'a', newline='') as file:
            writer = csv.writer(file)

            if not file_exists:
                writer.writerow(["First Name", "Last Name", "Birthday", "Email", "Gender", "Contact", "Address", "Password", "Role", "Registered On"])

    # write user data in csv
            writer.writerow([
                regis_entries["First Name"].get(),
                regis_entries["Last Name"].get(),
                regis_entries["Birthday (MM/DD/YYYY)"].get(),
                regis_entries["Email"].get(),
                regis_entries["Gender"].get(),
                regis_entries["Contact Number"].get(),
                regis_entries["Address"].get(),
                hashed_password,
                role_combobox.get(),
                datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            ])

        # show success message
        CTkMessagebox(title="Success", message="Registration successful!", icon="info")

        # clear the form
        clear_form()
        register_window.withdraw()
        main_window.after(100, main_window.deiconify)
        register_window.after(200, register_window.destroy)

    regis_button_frame = ctk.CTkFrame(regis_frame)
    regis_button_frame.grid(row=len(regis_labels)+2, column=0, columnspan=3, pady=20)

    submit_btn = ctk.CTkButton(regis_button_frame, text="Submit", fg_color="#7AB2D3", width=100, command=regis_success)
    submit_btn.grid(row=0, column=0, padx=5)

    clear_btn = ctk.CTkButton(regis_button_frame, text="Clear Form", fg_color="#CB5C5C", width=100, command=clear_form)
    clear_btn.grid(row=0, column=1, padx=5)

    def back_to_main():
        register_window.withdraw()
        main_window.after(100, main_window.deiconify)
        register_window.after(200, register_window.destroy)

    back_btn = ctk.CTkButton(regis_button_frame, text="Back", fg_color="#7AB2D3", width=100, command=back_to_main)
    back_btn.grid(row=0, column=2, padx=5)

def open_login_window():
    global email_entry, password_entry, login_window

    login_window = ctk.CTkToplevel(main_window)
    login_window.geometry("440x190")
    login_window.title("Login")
    main_window.withdraw()

    login_frame = ctk.CTkFrame(login_window)
    login_frame.pack(pady=20, padx=20, fill="both", expand=True)

    ctk.CTkLabel(login_frame, text="Email").grid(row=0, column=0, padx=5, pady=5, sticky='w')
    email_entry = ctk.CTkEntry(login_frame, width=250)
    email_entry.grid(row=0, column=1, padx=5, pady=5)

    ctk.CTkLabel(login_frame, text="Password").grid(row=1, column=0, padx=5, pady=5, sticky='w')
    password_entry = ctk.CTkEntry(login_frame, width=250, show="*")
    password_entry.grid(row=1, column=1, padx=5, pady=5)

    # password toggle 
    def password_toggle():
        if not password_entry.winfo_exists():
            return  # Prevent TclError
        if password_entry.cget("show") == "*":
            password_entry.configure(show="")
            toggle_btn.configure(text="Hide")
        else:
            password_entry.configure(show="*")
            toggle_btn.configure(text="Show")

    toggle_btn = ctk.CTkButton(login_frame, text="Show", width=60, fg_color="#7AB2D3", command=password_toggle)
    toggle_btn.grid(row=1, column=2, padx=5, pady=5)

    login_button_frame = ctk.CTkFrame(login_window)
    login_button_frame.pack(pady=20, padx=20)

    login_btn = ctk.CTkButton(login_button_frame, text="Login", fg_color="#7AB2D3", width=150, command=login)
    login_btn.grid(row=0, column=0, padx=5)

    def back_to_login_main():
        login_window.withdraw()
        main_window.after(100, main_window.deiconify)
        login_window.after(200, login_window.destroy)

    back_btn = ctk.CTkButton(login_button_frame, text="Back", fg_color="#7AB2D3", width=150, command=back_to_login_main)
    back_btn.grid(row=0, column=1)

def login():
    user_email = email_entry.get()
    user_password = password_entry.get()
    hashed_input_password = hashlib.sha256(user_password.encode()).hexdigest()

    # check matching inputted data from csv file
    try:
        with open("user_data.csv", 'r', encoding="utf-8") as file:
            reader = csv.reader(file)
            next(reader)
            for row in reader:
                if row[3] == user_email and row[7] == hashed_input_password:
                    user_role = row[8]
                    full_name = f"{row[0]} {row[1]}"
                    CTkMessagebox(title="Success", message="Login successful!", icon="info")
                    login_window.withdraw()
                    main_window.after(100, main_window.withdraw)  # Keeps main hidden if you're launching the app
                    login_window.after(200, login_window.destroy)
                    launch_hospital_app(full_name, user_role)
                    return

        CTkMessagebox(title="Error", message="Invalid email or password.")
    except FileNotFoundError:
        CTkMessagebox(title="Error", message="No user data found. Please register first.")

# application start
if __name__ == "__main__":
    open_main_window()