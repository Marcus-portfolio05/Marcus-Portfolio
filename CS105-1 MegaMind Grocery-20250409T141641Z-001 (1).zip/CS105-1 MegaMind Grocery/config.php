<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>

<?php
$servername = "sql302.infinityfree.com";  
$username = "if0_38642093";      
$password = "OQIAZM3OUfb1JE";      
$dbname = "if0_38642093_mmg";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>