<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>

include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_product'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $image = $_POST['image'];
    $description = $_POST['description'];

    $stmt = $conn->prepare("INSERT INTO products (name, price, image, description) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sdss", $name, $price, $image, $description);
    $stmt->execute();
    echo "Product added!";
}
?>
<form method="POST">
  Name: <input name="name" required><br>
  Price: <input name="price" type="number" step="0.01" required><br>
  Image URL: <input name="image"><br>
  Description:<br>
  <textarea name="description"></textarea><br>
  <button type="submit" name="add_product">Add Product</button>
</form>

<?php
/**
 * STEP 7: Product Listing (index.php)
 * Location: /htdocs/index.php
 * This file pulls product data from your MySQL database using config.php
 */
include 'config.php';

$result = $conn->query("SELECT * FROM products");
while ($row = $result->fetch_assoc()) {
    echo "<div><img src='{$row['image']}' width='100'><br>{$row['name']} - \${$row['price']}<br>
    <a href='cart.php?add={$row['id']}'>Add to Cart</a></div><hr>";
}