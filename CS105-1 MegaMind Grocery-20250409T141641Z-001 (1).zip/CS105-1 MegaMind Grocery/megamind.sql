-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 07, 2025 at 06:05 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `megamind`
--

-- --------------------------------------------------------

--
-- Table structure for table `alcoholic beverages`
--

CREATE TABLE `alcoholic beverages` (
  `Product_ID` varchar(100) DEFAULT NULL,
  `Product_Name` varchar(100) NOT NULL,
  `Price` double NOT NULL,
  `Source_ID` varchar(100) NOT NULL,
  `Stock/Unit_Amount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `alcoholic beverages`
--

INSERT INTO `alcoholic beverages` (`Product_ID`, `Product_Name`, `Price`, `Source_ID`, `Stock/Unit_Amount`) VALUES
('AB001', 'Oppa Strawberry Soju 360mL	', 104.95, 'SIB', 100),
('AB002', 'Oppa Peach Soju 360mL	', 104.95, 'SIB', 100),
('AB003', 'Oppa Green Grape Soju 360mL	', 104.95, 'SIB', 100),
('AB004', 'Carinvs Tempranillo Garnacha Cabernet Wine 750mL	', 499.95, 'SIB', 100),
('AB005', 'Rondel Gold Brut Cava Sparkling Wine 750mL	', 799.95, 'SIB', 100),
('AB006', 'Faustino Rivero Ulecia Gold Moscato 750mL	', 699.95, 'SIB', 100),
('AB007', 'Amahle Cabernet Sauvignon Wine 750 mL	', 699.95, 'SIB', 100),
('AB008', 'Cape Sweet Red Wine 750 mL	', 599.95, 'SIB', 100),
('AB009', 'BioMio Organic Red Sangria 750mL	', 749.95, 'SIB', 100),
('AB010', 'Hardys Varietal Range Merlot Red Wine 750mL	', 409.95, 'SIB', 100),
('AB011', 'Hardys Varietal Range Cabernet Sauvignon Red Wine 750mL	', 409.95, 'SIB', 100),
('AB012', 'Woomera Cabernet Merlot Red Wine 750mL	', 419.95, 'SIB', 100),
('AB013', 'Woomera Sweet Red Wine 750mL	', 339, 'SIB', 100),
('AB014', 'Faustino Rivero Reserva Red Wine 750ML	', 799, 'SIB', 100),
('AB015', 'Barefoot Pink Moscato 750mL	', 429.95, 'SIB', 100);

-- --------------------------------------------------------

--
-- Table structure for table `beverages`
--

CREATE TABLE `beverages` (
  `Product_ID` varchar(100) NOT NULL,
  `Product_Name` varchar(100) NOT NULL,
  `Price` double DEFAULT NULL,
  `Source_ID` varchar(100) NOT NULL,
  `Unit/Stock_Amount` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `beverages`
--

INSERT INTO `beverages` (`Product_ID`, `Product_Name`, `Price`, `Source_ID`, `Unit/Stock_Amount`) VALUES
('BV001', 'UCC Tokyo Cuppa Rich Black Coffee 250mL', 69.95, 'SIB', 100),
('BV002', 'Starbucks Mocha Frappuccino Chilled Coffee Drink 281mL', 129.95, 'SIB', 100),
('BV003', 'Nestle Milo Ready-to-Drink 6 x 180mL Promo Pack', 141.95, 'SIB', 100),
('BV004', 'Coca-Cola Original Taste 1.5L', 64.25, 'SIB', 100),
('BV005', 'Sprite 1.5L', 64.25, 'SIB', 100),
('BV006', 'Rite ‘N Lite Assorted Soda Promo Pack 6 x 250mL', 149.95, 'SIA', 100),
('BV007', 'Royal Tru-Orange 1.5L', 64.25, 'SIA', 100),
('BV008', 'Suntory Craft Boss Coffee Latte 500mL', 139.95, 'SIB', 100),
('BV009', 'Monster Green Energy Drink 355mL', 85.25, 'SIB', 100),
('BV010', 'Pocari Sweat Ion Supply Drink 4 x 500mL', 192.95, 'SIB', 100),
('BV011', 'Gatorade Blue Bolt Sports Drink 1.5L', 110.25, 'SIB', 100),
('BV012', 'Arizona Green Tea Cucumber with Citrus 680mL', 89.95, 'SIB', 100),
('BV013', 'Schlurp Brewed Wintermelon Milktea 500mL', 91.75, 'SIA', 100),
('BV014', 'Wilkins Pure Purified Water 24 x 500mL', 255.25, 'SIA', 100),
('BV015', 'Absolute Pure Distilled Drinking Water 24 x 250mL', 345.25, 'SIA', 100),
('BV016', 'Summit Natural Drinking Water 35 x 350mL', 275.25, 'SIA', 100),
('BV017', 'Del Monte A-C-E Pineapple Juice 1L', 101.95, 'SIA', 100),
('BV018', 'Minute Maid Nutri+ Orange Juice Drink 1L', 59.95, 'SIB', 100),
('BV019', 'Del Monte Four Seasons Juice Drink 1L', 99.95, 'SIA', 100),
('BV020', 'Welch’s Concord Grape Juice Family Size 2.83L', 549.95, 'SIB', 100);

-- --------------------------------------------------------

--
-- Table structure for table `canned goods`
--

CREATE TABLE `canned goods` (
  `Product_ID` varchar(100) NOT NULL,
  `Product_Name` varchar(100) NOT NULL,
  `Price` double DEFAULT NULL,
  `Source_ID` varchar(100) NOT NULL,
  `Stock/Unit_Amount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `canned goods`
--

INSERT INTO `canned goods` (`Product_ID`, `Product_Name`, `Price`, `Source_ID`, `Stock/Unit_Amount`) VALUES
('CG001', 'Campbell’s Cream of Mushroom 284 ML', 94, 'SIB', 100),
('CG002', 'SPAM Luncheon Meat 340G', 207.65, 'SIB', 100),
('CG003', 'PALM Corned Beef 326G', 262, 'SIB', 100),
('CG004', 'Purefood’s Corned Beef 380G', 187.95, 'SIA', 100),
('CG005', 'SeaKing Spanish Style Bangus 220g', 151.95, 'SIA', 100),
('CG006', 'Temple Brand Salted Black Beans 180g', 30.95, 'SIA', 100),
('CG007', 'Mega Prime Cream Corn 425g', 44.95, 'SIA', 100),
('CG008', 'Molinera Crushed Tomatoes 400g', 80.95, 'SIB', 100),
('CG009', 'Purefoods Bilbao Style Chorizo 210g', 153.95, 'SIA', 100),
('CG010', 'Unmeat Corned Beef Style 200g', 97.95, 'SIA', 100),
('CG011', 'Founders Whole Shiitake Mushroom 284g', 47.95, 'SIA', 100),
('CG012', 'Libby\'s Chicken Vienna Sausage 130g', 72.95, 'SIB', 100),
('CG013', 'Del Monte Whole Kernel Corn 420g', 50, 'SIA', 100),
('CG014', 'Hormel Chili No Beans 15oz', 204.95, 'SIB', 100);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `Purchase_ID` int(11) NOT NULL,
  `Product_ID` varchar(100) NOT NULL,
  `Customer_ID` varchar(99) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Price` int(11) NOT NULL,
  `Product_Name` varchar(99) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`Purchase_ID`, `Product_ID`, `Customer_ID`, `Quantity`, `Price`, `Product_Name`) VALUES
(0, 'AB001', '', 0, 0, ''),
(0, 'AB002', '', 0, 0, ''),
(0, 'AB003', '', 0, 0, ''),
(0, 'AB004', '', 0, 0, ''),
(0, 'AB005', '', 0, 0, ''),
(0, 'AB006', '', 0, 0, ''),
(0, 'AB007', '', 0, 0, ''),
(0, 'AB008', '', 0, 0, ''),
(0, 'AB009', '', 0, 0, ''),
(0, 'AB010', '', 0, 0, ''),
(0, 'AB011', '', 0, 0, ''),
(0, 'AB012', '', 0, 0, ''),
(0, 'AB013', '', 0, 0, ''),
(0, 'AB014', '', 0, 0, ''),
(0, 'AB015', '', 0, 0, ''),
(0, 'BV001', '', 0, 0, ''),
(0, 'BV002', '', 0, 0, ''),
(0, 'BV003', '', 0, 0, ''),
(0, 'BV004', '', 0, 0, ''),
(0, 'BV005', '', 0, 0, ''),
(0, 'BV006', '', 0, 0, ''),
(0, 'BV007', '', 0, 0, ''),
(0, 'BV008', '', 0, 0, ''),
(0, 'BV009', '', 0, 0, ''),
(0, 'BV010', '', 0, 0, ''),
(0, 'BV011', '', 0, 0, ''),
(0, 'BV012', '', 0, 0, ''),
(0, 'BV013', '', 0, 0, ''),
(0, 'BV014', '', 0, 0, ''),
(0, 'BV015', '', 0, 0, ''),
(0, 'BV016', '', 0, 0, ''),
(0, 'BV017', '', 0, 0, ''),
(0, 'BV018', '', 0, 0, ''),
(0, 'BV019', '', 0, 0, ''),
(0, 'BV020', '', 0, 0, ''),
(0, 'CD001', '', 0, 0, ''),
(0, 'CD002', '', 0, 0, ''),
(0, 'CD003', '', 0, 0, ''),
(0, 'CD004', '', 0, 0, ''),
(0, 'CD005', '', 0, 0, ''),
(0, 'CD006', '', 0, 0, ''),
(0, 'CD007', '', 0, 0, ''),
(0, 'CD008', '', 0, 0, ''),
(0, 'CD009', '', 0, 0, ''),
(0, 'CD010', '', 0, 0, ''),
(0, 'CD011', '', 0, 0, ''),
(0, 'CD012', '', 0, 0, ''),
(0, 'CF001', '', 0, 0, ''),
(0, 'CF002', '', 0, 0, ''),
(0, 'CF003', '', 0, 0, ''),
(0, 'CF004', '', 0, 0, ''),
(0, 'CF005', '', 0, 0, ''),
(0, 'CF006', '', 0, 0, ''),
(0, 'CF007', '', 0, 0, ''),
(0, 'CF008', '', 0, 0, ''),
(0, 'CF009', '', 0, 0, ''),
(0, 'CF010', '', 0, 0, ''),
(0, 'CF011', '', 0, 0, ''),
(0, 'CF012', '', 0, 0, ''),
(0, 'CF013', '', 0, 0, ''),
(0, 'CF014', '', 0, 0, ''),
(0, 'CF015', '', 0, 0, ''),
(0, 'CG001', '', 0, 0, ''),
(0, 'CG002', '', 0, 0, ''),
(0, 'CG003', '', 0, 0, ''),
(0, 'CG004', '', 0, 0, ''),
(0, 'CG005', '', 0, 0, ''),
(0, 'CG006', '', 0, 0, ''),
(0, 'CG007', '', 0, 0, ''),
(0, 'CG008', '', 0, 0, ''),
(0, 'CG009', '', 0, 0, ''),
(0, 'CG010', '', 0, 0, ''),
(0, 'CG011', '', 0, 0, ''),
(0, 'CG012', '', 0, 0, ''),
(0, 'CG013', '', 0, 0, ''),
(0, 'CG014', '', 0, 0, ''),
(0, 'DP001', '', 0, 0, ''),
(0, 'DP002', '', 0, 0, ''),
(0, 'DP003', '', 0, 0, ''),
(0, 'DP004', '', 0, 0, ''),
(0, 'DP005', '', 0, 0, ''),
(0, 'DP006', '', 0, 0, ''),
(0, 'DP007', '', 0, 0, ''),
(0, 'DP008', '', 0, 0, ''),
(0, 'DP009', '', 0, 0, ''),
(0, 'DP010', '', 0, 0, ''),
(0, 'DP011', '', 0, 0, ''),
(0, 'DP012', '', 0, 0, ''),
(0, 'DP013', '', 0, 0, ''),
(0, 'DP014', '', 0, 0, ''),
(0, 'DP015', '', 0, 0, ''),
(0, 'DP016', '', 0, 0, ''),
(0, 'DP017', '', 0, 0, ''),
(0, 'DP018', '', 0, 0, ''),
(0, 'DP019', '', 0, 0, ''),
(0, 'DP020', '', 0, 0, ''),
(0, 'DP021', '', 0, 0, ''),
(0, 'DP022', '', 0, 0, ''),
(0, 'DP023', '', 0, 0, ''),
(0, 'DP024', '', 0, 0, ''),
(0, 'DP025', '', 0, 0, ''),
(0, 'FM001', '', 0, 0, ''),
(0, 'FM002', '', 0, 0, ''),
(0, 'FM003', '', 0, 0, ''),
(0, 'FM004', '', 0, 0, ''),
(0, 'FM005', '', 0, 0, ''),
(0, 'FM006', '', 0, 0, ''),
(0, 'FM007', '', 0, 0, ''),
(0, 'FM008', '', 0, 0, ''),
(0, 'FM009', '', 0, 0, ''),
(0, 'FM010', '', 0, 0, ''),
(0, 'FM011', '', 0, 0, ''),
(0, 'FM012', '', 0, 0, ''),
(0, 'FM013', '', 0, 0, ''),
(0, 'FM014', '', 0, 0, ''),
(0, 'FM015', '', 0, 0, ''),
(0, 'FM016', '', 0, 0, ''),
(0, 'FM017', '', 0, 0, ''),
(0, 'FM018', '', 0, 0, ''),
(0, 'FM019', '', 0, 0, ''),
(0, 'FM020', '', 0, 0, ''),
(0, 'HC001', '', 0, 0, ''),
(0, 'HC002', '', 0, 0, ''),
(0, 'HC003', '', 0, 0, ''),
(0, 'HC004', '', 0, 0, ''),
(0, 'HC005', '', 0, 0, ''),
(0, 'HC006', '', 0, 0, ''),
(0, 'HC007', '', 0, 0, ''),
(0, 'HC008', '', 0, 0, ''),
(0, 'HC009', '', 0, 0, ''),
(0, 'HC010', '', 0, 0, ''),
(0, 'HC011', '', 0, 0, ''),
(0, 'HC012', '', 0, 0, ''),
(0, 'HC013', '', 0, 0, ''),
(0, 'HC014', '', 0, 0, ''),
(0, 'HC015', '', 0, 0, ''),
(0, 'HC016', '', 0, 0, ''),
(0, 'HC017', '', 0, 0, ''),
(0, 'HC018', '', 0, 0, ''),
(0, 'HC019', '', 0, 0, ''),
(0, 'HC020', '', 0, 0, ''),
(0, 'HC021', '', 0, 0, ''),
(0, 'HC022', '', 0, 0, ''),
(0, 'HC023', '', 0, 0, ''),
(0, 'HC024', '', 0, 0, ''),
(0, 'HC025', '', 0, 0, ''),
(0, 'HP001', '', 0, 0, ''),
(0, 'HP002', '', 0, 0, ''),
(0, 'HP003', '', 0, 0, ''),
(0, 'HP004', '', 0, 0, ''),
(0, 'HP005', '', 0, 0, ''),
(0, 'HP006', '', 0, 0, ''),
(0, 'HP007', '', 0, 0, ''),
(0, 'HP008', '', 0, 0, ''),
(0, 'HP009', '', 0, 0, ''),
(0, 'HP010', '', 0, 0, ''),
(0, 'HP011', '', 0, 0, ''),
(0, 'HP012', '', 0, 0, ''),
(0, 'HP013', '', 0, 0, ''),
(0, 'HP014', '', 0, 0, ''),
(0, 'HP015', '', 0, 0, ''),
(0, 'PC001', '', 0, 0, ''),
(0, 'PC002', '', 0, 0, ''),
(0, 'PC003', '', 0, 0, ''),
(0, 'PC004', '', 0, 0, ''),
(0, 'PC005', '', 0, 0, ''),
(0, 'PC006', '', 0, 0, ''),
(0, 'PC007', '', 0, 0, ''),
(0, 'PC008', '', 0, 0, ''),
(0, 'PC009', '', 0, 0, ''),
(0, 'PC010', '', 0, 0, ''),
(0, 'SP001', '', 0, 0, ''),
(0, 'SP002', '', 0, 0, ''),
(0, 'SP003', '', 0, 0, ''),
(0, 'SP004', '', 0, 0, ''),
(0, 'SP005', '', 0, 0, ''),
(0, 'SP006', '', 0, 0, ''),
(0, 'SP007', '', 0, 0, ''),
(0, 'SP008', '', 0, 0, ''),
(0, 'SP009', '', 0, 0, ''),
(0, 'SP010', '', 0, 0, ''),
(0, 'SP011', '', 0, 0, ''),
(0, 'SP012', '', 0, 0, ''),
(0, 'SP013', '', 0, 0, ''),
(0, 'SP014', '', 0, 0, ''),
(0, 'SP015', '', 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `chilled and frozen goods`
--

CREATE TABLE `chilled and frozen goods` (
  `Product_ID` varchar(100) NOT NULL,
  `Product_Name` varchar(100) NOT NULL,
  `Price` double NOT NULL,
  `Source_ID` varchar(100) NOT NULL,
  `Stock/Unit_Amount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chilled and frozen goods`
--

INSERT INTO `chilled and frozen goods` (`Product_ID`, `Product_Name`, `Price`, `Source_ID`, `Stock/Unit_Amount`) VALUES
('CF001', 'Espuna Tapas Fuet D\' Olot 60g	', 199.95, 'SIB', 100),
('CF002', 'SeaKing Marinated Hot Boneless Milkfish Bangus 500g	', 274.95, 'SIA', 100),
('CF003', 'Rico\'s Spicy Lechon 500g	', 719.95, 'SIA', 100),
('CF004', 'Bounty Fresh Sweet and Sour Saucy Torikaraage 450g	', 278.95, 'SIA', 100),
('CF005', 'Taiwan Balls Cheese Fish Bun 750g	', 459.95, 'SIB', 100),
('CF006', 'CDO Funtastyk Young Pork Tocino 1 kg	', 357.25, 'SIA', 100),
('CF007', 'Crabsticks 1kg	', 344.95, 'SIA', 100),
('CF008', 'Swiss Deli Beef Hungarian Sausage 500g	', 482, 'SIB', 100),
('CF009', 'Aqua Star Salt & Pepper Crispy Calamari 500g	', 699.95, 'SIB', 100),
('CF010', 'Bounty Fresh Chicken Nuggets 750g	', 319.95, 'SIA', 100),
('CF011', 'Purefoods Tender Juicy Classic Hotdog 1kg	', 211, 'SIA', 100),
('CF012', 'Purefoods Classic Honeycured Bacon 1kg	', 718.5, 'SIA', 100),
('CF013', 'Grimm\'s Old Fashioned Ham 800g	', 799.95, 'SIB', 100),
('CF014', 'Cardinal Roadhouse Pulled Pork in BBQ Sauce 400g	', 399.95, 'SIB', 100),
('CF015', 'Johnsonville Original Smoked Sausage 360g	', 374.95, 'SIB', 100);

-- --------------------------------------------------------

--
-- Table structure for table `condiments and dressings`
--

CREATE TABLE `condiments and dressings` (
  `Product_ID` varchar(100) DEFAULT NULL,
  `Product_Name` varchar(100) NOT NULL,
  `Price` double NOT NULL,
  `Source_ID` varchar(100) NOT NULL,
  `Stock/Unit_Amount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `condiments and dressings`
--

INSERT INTO `condiments and dressings` (`Product_ID`, `Product_Name`, `Price`, `Source_ID`, `Stock/Unit_Amount`) VALUES
('CD001', 'Lady\'s Choice Real Mayonnaise Pouch 470mL', 189, 'SIA', 100),
('CD002', 'Huy Fong Sriracha Chili Sauce 435mL', 308, 'SIB', 100),
('CD003', 'Heinz Tomato Ketchup 1.25kg', 289.25, 'SIB', 100),
('CD004', 'Wish-Bone Light Creamy Caesar Dressing 444mL', 249.95, 'SIB', 100),
('CD005', 'Mang Tomas All-Around Sarsa 550g', 51, 'SIA', 100),
('CD006', 'TGI Fridays Buffalo Ranch Wing and Dipping Sauce 340g', 269.95, 'SIB', 100),
('CD007', 'Hidden Valley Ranch Homestyle Dressing 1.18L	', 559.95, 'SIB', 100),
('CD008', 'Lea & Perrins Worcestershire Sauce 290mL	', 235.95, 'SIB', 100),
('CD009', 'Kikkoman Low Sodium Soy Sauce 1.2L	', 699, 'SIB', 100),
('CD010', 'Silver Swan Soy Sauce 1.893L	', 101, 'SIA', 100),
('CD011', 'Datu Puti White Vinegar 1.89L	', 84, 'SIA', 100),
('CD012', 'Lee Kum Kee Panda Brand Oyster Sauce 907g	', 235, 'SIB', 100);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `first_name` varchar(99) NOT NULL,
  `last_name` varchar(99) NOT NULL,
  `location` varchar(100) NOT NULL,
  `mobile_number` int(11) NOT NULL,
  `Customer_ID` varchar(99) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dairy`
--

CREATE TABLE `dairy` (
  `ProductID` varchar(100) NOT NULL,
  `ProductName` varchar(100) NOT NULL,
  `Price` double NOT NULL,
  `Source_ID` varchar(100) NOT NULL,
  `Unit/Stock_Amount` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dairy`
--

INSERT INTO `dairy` (`ProductID`, `ProductName`, `Price`, `Source_ID`, `Unit/Stock_Amount`) VALUES
('DP001', 'Queensland Unsalted Butter 225g', 130.95, 'SIB', 100),
('DP002', 'Lurpak Salted Butter 200g', 228.25, 'SIB', 100),
('DP003', 'Arla Cheese Triangles 140g', 116.95, 'SIA', 100),
('DP004', 'Arla Natural Cheddar Chunk 200g', 258.25, 'SIA', 100),
('DP005', 'Magnolia Cheezee Regular 430g', 134.95, 'SIA', 100),
('DP006', 'Eden Melt Sarap Quick Melting Cheese 1.9KG', 666.95, 'SIA', 100),
('DP007', 'Nestle All-Purpose Cream 250mL', 69.95, 'SIA', 100),
('DP008', 'Nestle Sour Cream 240g', 150, 'SIA', 100),
('DP009', 'Island Farms Chocolate Milk Ice Cream 4L', 849.95, 'SIB', 100),
('DP010', 'Island farms Neopolitan Ice Cream 4L', 849.95, 'SIB', 100),
('DP011', 'Ben & Jerry’s Chocolate Chip Cookie Dough Core Ice Cream Pint', 394.95, 'SIB', 100),
('DP012', 'Ben & Jerry’s Pistachio Ice Cream Pint', 394.95, 'SIB', 100),
('DP013', 'Ferrero Rocher Hazelnut Ice Cream 4 x 70mL', 422.95, 'SIB', 100),
('DP014', 'Meiji Almond Chocolate Ice Cream Bar 6 x 47mL', 399.95, 'SIB', 100),
('DP015', 'Yakult Probiotics Drink 5 x 80mL', 48.5, 'SIA', 100),
('DP016', 'Dutch Mill Delight Probiotic Drink 5 x 100mL', 57, 'SIA', 100),
('DP017', 'Cowhead Premium Chocolate Milk 1L', 114.25, 'SIB', 100),
('DP018', 'Cowhead Lite Low-Fat Pure Milk 1L', 101.25, 'SIB', 100),
('DP019', 'Cowhead Lactose Free Pure Milk 1L', 120.25, 'SIB', 100),
('DP020', 'Nestle Fresh Milk 2 x 1L Promo Pack', 195.95, 'SIA', 100),
('DP021', 'Oastside Barista Blend Oat Milk 1L', 146.25, 'SIB', 100),
('DP022', 'Alaska Classic Evaporated Filled Milk 360mL', 55.95, 'SIA', 100),
('DP023', 'Bear Brand Fortified Powdered Milk Drink 2.4kg', 824.25, 'SIA', 100),
('DP024', 'Holly’s Low Fat Yoghurt 1L', 199, 'SIA', 100),
('DP025', 'Holly’s Yoghurt Non Fat 500mL', 124.95, 'SIA', 100);

-- --------------------------------------------------------

--
-- Table structure for table `fresh meat`
--

CREATE TABLE `fresh meat` (
  `ProductID` varchar(100) NOT NULL,
  `ProductName` varchar(100) NOT NULL,
  `Price` double NOT NULL,
  `Source_ID` varchar(100) NOT NULL,
  `Unit/Stock_Amount` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fresh meat`
--

INSERT INTO `fresh meat` (`ProductID`, `ProductName`, `Price`, `Source_ID`, `Unit/Stock_Amount`) VALUES
('FM001', 'Farm\'s Choice Chicken Wings 1.4KG ', 280, 'SIA', 100),
('FM002', 'Farm’s Choice Chicken Breast 1.4KG', 264.6, 'SIA', 100),
('FM003', 'Farm’s Choice Chicken Thigh 1.4KG', 264.6, 'SIA', 100),
('FM004', 'Farm’s Choice Chicken Ground 1.4KG', 264.6, 'SIA', 100),
('FM005', 'Farm’s Choice Chicken Whole 1.5KG', 270, 'SIA', 100),
('FM006', 'Farm’s Choice Ground Beef 1KG', 298, 'SIA', 100),
('FM007', 'Farm’s Choice Beef Cubes 1KG', 399, 'SIA', 100),
('FM008', 'Farm’s Choice Beef Shank 1.2KG', 478.8, 'SIA', 100),
('FM009', 'Farm’s Choice Beef Short Ribs 1KG', 609.25, 'SIA', 100),
('FM010', 'Farm’s Choice Beef Bulalo Cut 1.4KG', 460.6, 'SIA', 100),
('FM011', 'Farm’s Choice Beef Cubes 1KG', 495.25, 'SIA ', 100),
('FM012', 'Farm’s Choice Beef Pochero 500G', 174.98, 'SIA', 100),
('FM013', 'Farm’s Choice Ox Tripe 1.5KG', 322.5, 'SIA', 100),
('FM014', 'Farm’s Choice Pork Sinigang Cut 1.4KG', 217, 'SIA', 100),
('FM015', 'Farm’s Choice Pork Adobo Cut 1.2KG', 382.8, 'SIA', 100),
('FM016', 'Farm’s Choice Ground Pork 1.4KG', 376.6, 'SIA', 100),
('FM017', 'Farm’s Choice Pork Spare Ribs 1.2KG', 394.8, 'SIA', 100),
('FM018', 'Farm’s Choice Pork Liempo Slice 1KG', 389, 'SIA', 100),
('FM019', 'Farm’s Choice Pork Ribeye Steak 1KG', 318, 'SIA', 100);

-- --------------------------------------------------------

--
-- Table structure for table `home cleaning`
--

CREATE TABLE `home cleaning` (
  `ProductID` varchar(100) NOT NULL,
  `ProductName` varchar(100) NOT NULL,
  `Price` double NOT NULL,
  `Source_ID` varchar(100) NOT NULL,
  `Unit/Stock_Amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `home cleaning`
--

INSERT INTO `home cleaning` (`ProductID`, `ProductName`, `Price`, `Source_ID`, `Unit/Stock_Amount`) VALUES
('HC001', 'Domex Classic Ultra Thick Bleach Germ Kill Toilet Cleaner Liquid 900mL', 149.95, 'SIB', 100),
('HC002', 'Domestos Power 5 Rim Block Ocean Toilet Cleaner 55g', 119.95, 'SIB', 100),
('HC003', 'Clean Sweet Toilet Brush Rubber with Holder Blue Green', 179.95, 'SIB', 100),
('HC004', 'Lysol Lime & Rust Toilet Bowl Cleaner 709mL', 199.95, 'SIB', 100),
('HC005', 'Clorox Mold & Mildew Remover 500mL Saver Pack', 379.95, 'SIB ', 100),
('HC006', 'Sanicare Bathroom Tissue 3-Ply 600 Sheets 18 Rolls', 339.75, 'SIA', 100),
('HC007', 'Sanicare 2-Ply Jumbo Kitchen Towel 140s Twin Pack', 134.95, 'SIA', 100),
('HC008', 'Kleenex Facial Tissue 2-Ply Mainline Box 3 x 190s', 307.95, 'SIA', 100),
('HC009', 'Kami Interfolded Paper Towel 10 x 175s', 510.95, 'SIA ', 100),
('HC010', 'Phoenix Ultra Heavy-Duty Garbage Roll Bag X-Large', 194.95, 'SIB ', 100),
('HC011', 'Phoenix Ultra Heavy-Duty Garbage Roll Bag Large', 144.95, 'SIB', 100),
('HC012', 'Phoenix Ultra Heavy-Duty Garbage Roll Bag Medium', 129.95, 'SIB', 100),
('HC013', 'Phoenix Ultra Heavy-Duty Garbage Roll Bag Small', 104.95, 'SIB', 100),
('HC014', 'Scotch-Brite Heavy-Duty Antibacterial Scrub Sponge', 54.95, 'SIB', 100),
('HC015', 'Scotch-Brite Tough Clean Mini Scrub Sponge 3s', 69.95, 'SIB', 100),
('HC016', 'Scotch-Brite Heavy Duty Scrub Sponge 3s', 119.95, 'SIB', 100),
('HC017', 'Swiffer Sweeper Wet Mopping Cloths 2 x 32 Refills', 1599.95, 'SIB', 100),
('HC018', 'Mr. Muscle Sink & Drain Declogger 500mL', 132.25, 'SIA', 100),
('HC019', 'Clorox All-Purpose Cleaner Spray 500mL', 149.95, 'SIB', 100),
('HC020', 'Pine-Sol Lavender Clean Multi-Surface Cleaner 1.77L', 409.95, 'SIA', 100),
('HC021', 'Scotch-Brite Tile & Grout Brush', 169.95, 'SIB', 100),
('HC022', 'Elbow Grease Super Strong Large Rubber Gloves', 134.95, 'SIA', 100),
('HC023', 'Clean Sweep Squeeze Foam Mop Refill', 129.95, 'SIA', 100),
('HC024', 'Scrubz SBZ-M028 Flat Mop', 409.95, 'SIB', 100),
('HC025', 'Swirl Lint Remover Twin Pack', 110.95, 'SIB', 100);

-- --------------------------------------------------------

--
-- Table structure for table `hygiene products`
--

CREATE TABLE `hygiene products` (
  `Product_ID` varchar(100) NOT NULL,
  `Product_Name` varchar(100) NOT NULL,
  `Price` double DEFAULT NULL,
  `Source_ID` varchar(100) NOT NULL,
  `Unit/Stock_Amount` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hygiene products`
--

INSERT INTO `hygiene products` (`Product_ID`, `Product_Name`, `Price`, `Source_ID`, `Unit/Stock_Amount`) VALUES
('HP001', 'Safeguard Floral Pink With Aloe Body Wash 1L', 269, 'SIB', 100),
('HP002', 'Safeguard Pure White Bar Soap 6 x 125g Value Pack', 275.95, 'SIB', 100),
('HP003', 'Oral-B 123 Fresh Mint Toothpaste 100mL', 159.95, 'SIB', 100),
('HP004', 'Milcu Underarm & Foot Deodorant Powder 80g', 95.95, 'SIA', 100),
('HP005', 'Head & Shoulders Anti Dandruff Antibac Shampoo 850mL', 499.95, 'SIB', 100),
('HP006', 'Dove Intensive Repair Shampoo 400mL', 250, 'SIB', 100),
('HP007', 'Cream Silk Rich Organic Powerfusion Rich Moisture Ultra Conditioner 300mL', 349.95, 'SIA', 100),
('HP008', 'Pantene 3-Minute Miracle Collagen Repair Conditioner 480mL', 469.95, 'SIB', 100),
('HP009', 'Listerine Fresh Burst Mouthwash 250mL', 117.75, 'SIB', 100),
('HP010', 'Colgate Cavity Protection Fluoride Toothpaste 226g', 199.95, 'SIB', 100),
('HP011', 'Oral-B Essential Dental Floss Mint 50m', 170, 'SIB', 100),
('HP012', 'Colgate SlimSoft Charcoal Ultra Soft Toothbrush Promo Pack', 425.95, 'SIB', 100),
('HP013', 'Modess Regular Cottony Soft Sanitary Pad with Wings 32s', 144.25, 'SIB', 100),
('HP014', 'Kotex Luxe 32cm Ultra Thin Overnight Sanitary Pad 3 x 8s', 339.95, 'SIB', 100),
('HP015', 'Betadine Povidone-Iodine Feminine Wash 100mL', 215.95, 'SIB', 100);

-- --------------------------------------------------------

--
-- Table structure for table `pet products`
--

CREATE TABLE `pet products` (
  `Product_ID` varchar(100) NOT NULL,
  `Product_Name` varchar(100) NOT NULL,
  `Price` double DEFAULT NULL,
  `Source_ID` varchar(100) NOT NULL,
  `Unit/Stock_Amount` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pet products`
--

INSERT INTO `pet products` (`Product_ID`, `Product_Name`, `Price`, `Source_ID`, `Unit/Stock_Amount`) VALUES
('PC001', 'Pedigree Dentastix Daily Oral Care Stick 270g', 199.95, 'SIB', 100),
('PC002', 'Shampooch Antibacterial Powdery Shampoo with Conditioner 1L', 339.95, 'SIA', 100),
('PC003', 'Purina Alpo Come & Get It! Mixed Dog Food 1.81KG', 329.95, 'SIB', 100),
('PC004', 'Special Delight Carbon Pet Training Pee Pads 45x60cm 50s', 359.95, 'SIB', 100),
('PC005', 'Puppy Love 3.7” Donut Dog Toy Assorted', 129.95, 'SIB', 100),
('PC006', 'Whiskas Tuna Flavor Adult Cat Food in Can 400g', 108.25, 'SIB', 100),
('PC007', 'Catsan Ultra Odor Control Cat Litter 5L', 224.95, 'SIB', 100),
('PC008', 'Shampooch Hypo Allergenic Tea Tree N\' Aloe Vera Cat Shampoo with Conditioner 1L', 399.95, 'SIA', 100),
('PC009', 'SmartHeart Creamy Salmon Cat Treats 60g', 99.95, 'SIB', 100),
('PC010', 'Litter Scoop 4.3\" 2 Assorted Color', 89.95, 'SIB', 100);

-- --------------------------------------------------------

--
-- Table structure for table `snacks`
--

CREATE TABLE `snacks` (
  `Product_ID` varchar(100) NOT NULL,
  `Product_Name` varchar(100) NOT NULL,
  `Price` double DEFAULT NULL,
  `Source_ID` varchar(100) NOT NULL,
  `Stock/Unit_Amount` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `snacks`
--

INSERT INTO `snacks` (`Product_ID`, `Product_Name`, `Price`, `Source_ID`, `Stock/Unit_Amount`) VALUES
('SP001', 'Cheetos Crunchy Cheese Flavored Snack 215g', 156.25, 'SIB', 100),
('SP002', 'Lay’s Classic Potato Chips 170g', 156.25, 'SIB', 100),
('SP003', 'Doritos Nacho Cheese Tortilla Chips 190g', 156.25, 'SIB', 100),
('SP004', 'Pringles Original Potato Crisps 149g', 108.25, 'SIB', 100),
('SP005', 'Nabisco Chips Ahoy! Original Chocolate Chip Cookies 368g', 284.95, 'SIB', 100),
('SP006', 'Meiji Yan Yan Creamy Chocolate Dip Biscuit Snack 10 x 50g', 479, 'SIB', 100),
('SP007', 'Kastel Butter Cookies Tin 340g', 199.95, 'SIB', 100),
('SP008', 'Orion Choco Pie 12s 360g', 147.95, 'SIB', 100),
('SP009', 'Oreo Original Vanilla Sandwich Cookies 9 x 27.6g', 78.95, 'SIB', 100),
('SP010', 'Loacker Quadratini Chocolate Wafer 250g', 201.95, 'SIB', 100),
('SP011', 'M.Y. San SkyFlakes Crackers 24 Single Packs', 132.95, 'SIA', 100),
('SP012', 'Boy Bawang Cornick Garlic Flavor 500g', 134.95, 'SIA', 100),
('SP013', 'Monde Classic Special Mamon 6 x 43g', 93.95, 'SIA', 100),
('SP014', 'Nutella Ferrero B-Ready 6 x 22g', 169.95, 'SIB', 100),
('SP015', 'Oreo Vanilla Wafer Roll 54g', 39.95, 'SIB', 100);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alcoholic beverages`
--
ALTER TABLE `alcoholic beverages`
  ADD KEY `Product_ID A/B` (`Product_ID`);

--
-- Indexes for table `canned goods`
--
ALTER TABLE `canned goods`
  ADD KEY `Product_ID` (`Product_ID`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`Product_ID`),
  ADD KEY `Customer_ID` (`Customer_ID`);

--
-- Indexes for table `chilled and frozen goods`
--
ALTER TABLE `chilled and frozen goods`
  ADD KEY `Product_ID C/F` (`Product_ID`);

--
-- Indexes for table `condiments and dressings`
--
ALTER TABLE `condiments and dressings`
  ADD KEY `Product_ID C/D` (`Product_ID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_ID`);

--
-- Indexes for table `fresh meat`
--
ALTER TABLE `fresh meat`
  ADD PRIMARY KEY (`ProductID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `alcoholic beverages`
--
ALTER TABLE `alcoholic beverages`
  ADD CONSTRAINT `Product_ID A/B` FOREIGN KEY (`Product_ID`) REFERENCES `cart` (`Product_ID`);

--
-- Constraints for table `canned goods`
--
ALTER TABLE `canned goods`
  ADD CONSTRAINT `Product_ID` FOREIGN KEY (`Product_ID`) REFERENCES `cart` (`Product_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
